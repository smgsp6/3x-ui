import { useMemo, useState } from 'react';
import { useLocation, useNavigate } from 'react-router';
import { useTranslation } from 'react-i18next';
import { Drawer } from 'antd';
import {
  AppstoreOutlined,
  CloudServerOutlined,
  HomeOutlined,
  SafetyCertificateOutlined,
  TeamOutlined,
} from '@ant-design/icons';
import { PANEL_ROUTES } from '@/routes/panelRoutes';
import './MiniAppBottomNav.css';

declare global {
  interface Window {
    X_UI_TG_MINIAPP_MODE?: boolean;
  }
}

const primary = [
  { path: '/', name: '首页', Icon: HomeOutlined },
  { path: '/nodes', name: '服务器', Icon: CloudServerOutlined },
  { path: '/clients', name: '客户端', Icon: TeamOutlined },
  { path: '/certificates', name: '证书', Icon: SafetyCertificateOutlined },
];

/** All advanced Xray settings remain reachable; do not hide features on mobile. */
export default function MiniAppBottomNav() {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const { pathname } = useLocation();
  const [moreOpen, setMoreOpen] = useState(false);
  const moreSelected = !primary.some((item) => item.path === pathname);
  const allRoutes = useMemo(
    () => PANEL_ROUTES.filter((route) => !primary.some((p) => p.path === route.path)),
    [],
  );

  if (!window.X_UI_TG_MINIAPP_MODE) return null;
  return (
    <>
      <nav className="tg-app-bottom-nav" aria-label="Vela 小程序主导航">
        {primary.map(({ path, name, Icon }) => (
          <button
            key={path}
            type="button"
            className={pathname === path ? 'tg-bottom-item active' : 'tg-bottom-item'}
            aria-current={pathname === path ? 'page' : undefined}
            onClick={() => navigate(path)}
          >
            <Icon aria-hidden />
            <span>{name}</span>
          </button>
        ))}
        <button
          type="button"
          className={moreSelected || moreOpen ? 'tg-bottom-item active' : 'tg-bottom-item'}
          aria-expanded={moreOpen}
          aria-controls="vela-more-drawer"
          onClick={() => setMoreOpen(true)}
        >
          <AppstoreOutlined aria-hidden />
          <span>更多</span>
        </button>
      </nav>
      <Drawer
        placement="bottom"
        size="min(75dvh, 620px)"
        open={moreOpen}
        onClose={() => setMoreOpen(false)}
        title="Vela · 全部功能"
        rootClassName="vela-more-drawer"
        styles={{ body: { padding: 18 } }}
      >
        <div className="vela-more-grid" id="vela-more-drawer">
          {allRoutes.map((route) => {
            const Icon = route.icon;
            return (
              <button
                type="button"
                className="vela-more-entry"
                key={route.path}
                onClick={() => { setMoreOpen(false); navigate(route.path); }}
              >
                <span className="vela-more-entry-icon"><Icon aria-hidden /></span>
                <span>{t(route.titleKey)}</span>
              </button>
            );
          })}
        </div>
      </Drawer>
    </>
  );
}
